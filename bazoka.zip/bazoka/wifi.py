bazoka1 = 10000000
while bazoka1 < 99999999 :
    bazoka1=bazoka1+1
    print (bazoka1)