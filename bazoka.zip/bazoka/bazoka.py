import os
os.system('clear')
from bazokab7x import *

def tool_name (tool_name) :
    print ("Welcome Back To Bazoka Tool", tool_name)

tool_name (" ,We Are The best..!")

print ("First , You Should Verify Your Self By Typing 'bazoka'")

name = input("Verify Your Self To Get access : ")

if name == "bazoka" :
    print ("Thank You, You Have Access Now 'Done'.....!")

else:
    print ("You Should Type 'bazoka...!")
    input ("=============>: ")
    name = 'baozka'
    if name == "bazoka" :
        print("Thank You, You Have Access Now 'Done'.....!")
ba1 = ["Thanks , You Should Type Your Informations ..! Please.." , "Dev By Bazoka"]
print (ba1)
ba2 = input ("Type Your Name: ")
print ("Nice Name ...!MR, : " + ba2)
ba3 = input ("Now , Type Your Age: ")
print ("Thanks, Your Age Is : " + ba3)
ba4 = input ("Finally Type 'Yes' If You Want My Phone Number : ")
if ba4 == "Yes" :
    ba5 = ("My Phone IS : +201098617164, Dev By Bazoka")
    print (ba5)

print()
print()
print('\033[0;31m Dev By Bazoooooooka')
print()
print()

print ('\033[0;31m 1- Wifi Password List (Gussing) ')
print ('\033[0;31m 2- Check Ip and Opened Ports Tool')
print ('\033[0;31m 3- Check IP of Any Website www.example.com')
print ('\033[0;31m 4- Informations About Devs')

z = input("\033[0;31m Type The Number Of Your Best Tool=====>: ")

if z == '1':
    from wifi import *
    print('\033[1;32m Dev By Bazoka , See You Soon....!')
    from bazokatools import *

elif z == '2':
    ###############
    import socket
    import sys
    from time import *
    from datetime import datetime

    ####################
    ip = input("===> ENTER YOUR IP TO START: ")
    t1 = datetime.now()
    print("Scanning Start.. %s Please Wait.. " % ip)
    sleep(1)
    ####################
    try:
        for port in range(1, 6553):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if (s.connect_ex((ip, port)) == 0):
                try:
                    serv = socket.getservbyport(port)

                except socket.error:
                    serv = "Unknown Service"
                print("Port %s Open Service:%s " % (port, serv))
            t2 = datetime.now()
            t3 = t2 - t1
        print("Scanning Completed On %s" % t3)
    except KeyboardInterrupt:
        print("See You Soon....!")
######################################################################################
elif z=='3':
    import socket
    import sys
    from datetime import datetime
    from time import *
    ######################
    print ('\033[0;34m ENTER YOUR TARGET OR WEBSITE: ')
    t1=datetime.now()
    hostname = input()
    ip=socket.gethostbyname(hostname)
    print ('Host Name Is: ',hostname, 'Target IP is: ',ip)
    t2=datetime.now()
    t3=t2-t1
    print("Scannig Completed On %s" %t3)
    print('\033[1;32m Dev By Bazoka , See You Soon....!')
    print()
    print()
    print()
    print()
    print()
    from bazokatools import *
#############################################################

elif z=='4':
    print('\033[0;34m Dev By Bazoooka "An Egyptian Developer"')
    print()
    print()
    print('This Tool Has A lot Prons,And I Will Make This Tool Better, Commuincate With Me , +201098617164')
    print("Thank You For Downloding My Tool...! Have Fun....")
    print()
    print()
    print()
    print()
    print()
    print()
    from bazokatools import *